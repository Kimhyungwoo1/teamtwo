package com.meister.opensource.vo;

public class OpensourceVO {
	
	private String opensourceId;
	private int likeCount;
	
	public String getOpensourceId() {
		return opensourceId;
	}
	
	public void setOpensourceId(String opensourceId) {
		this.opensourceId = opensourceId;
	}
	
	public int getLikeCount() {
		return likeCount;
	}
	
	public void setLikeCount(int likeCount) {
		this.likeCount = likeCount;
	}

}
