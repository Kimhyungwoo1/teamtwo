package com.meister.authorization.biz;

public interface AuthorizationBiz {

}
