package com.meister.authorization.vo;

public class AuthorizationVO {

	private String AuthorizationId;
	private String AuthorizationName;

	public String getAuthorizationId() {
		return AuthorizationId;
	}

	public void setAuthorizationId(String authorizationId) {
		AuthorizationId = authorizationId;
	}

	public String getAuthorizationName() {
		return AuthorizationName;
	}

	public void setAuthorizationName(String authorizationName) {
		AuthorizationName = authorizationName;
	}
	
}
