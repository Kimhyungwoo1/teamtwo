package com.meister.authorization.service;

public interface AuthorizationService {

}
