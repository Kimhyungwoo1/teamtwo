package com.meister.authorization.dao;

public interface AuthorizationDao {

}
