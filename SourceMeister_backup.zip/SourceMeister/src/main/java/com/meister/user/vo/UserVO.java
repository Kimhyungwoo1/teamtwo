package com.meister.user.vo;

public class UserVO {

}
