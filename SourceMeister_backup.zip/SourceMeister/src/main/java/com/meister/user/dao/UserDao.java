package com.meister.user.dao;

public interface UserDao {

}
