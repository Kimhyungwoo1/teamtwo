package com.meister.user.biz;

public interface UserBiz {

}
