package com.meister.user.service;

public interface UserService {

}
